<?php
function parseDate($dateString) {
    // Trim any whitespace
    $dateString = trim($dateString);

    $formats = [
        'd/m/Y', // DD/MM/YYYY
        'm/d/Y', // MM/DD/YYYY
        'Y-m-d'  // YYYY-MM-DD
    ];

    foreach ($formats as $format) {
        $date = DateTime::createFromFormat($format, $dateString);
        if ($date && $date->format($format) === $dateString) {
            return $date->format('Y-m-d'); // Convert to MySQL format
        }
    }
    return false;
}

function validateCsvRow($row) {
    $errors = [];

    // Check required fields
    if (empty(trim($row['title']))) {
        $errors[] = "Title is required";
    }

    if (empty(trim($row['release_at']))) {
        $errors[] = "Release date is required";
    } else {
        $validDate = parseDate($row['release_at']);
        if (!$validDate) {
            $errors[] = "Invalid date format for: " . $row['release_at'];
        }
    }

    if (empty(trim($row['summary']))) {
        $errors[] = "Summary is required";
    }

    return $errors;
}

function processCsvImport($conn, $file) {
    $result = [
        'success' => 0,
        'errors' => 0,
        'messages' => [],
        'debug' => [] // For debugging purposes
    ];

    // Set max execution time to 5 minutes
    set_time_limit(300);

    try {
        if (($handle = fopen($file, "r")) !== FALSE) {
            // Read and validate header row
            $header = fgetcsv($handle, 1000, ";");
            if ($header === false) {
                throw new Exception("Could not read CSV header");
            }

            // Normalize header names
            $header = array_map(function($column) {
                return strtolower(trim($column));
            }, $header);

            // Debug header
            $result['debug'][] = "Headers found: " . implode(", ", $header);

            // Validate required columns exist
            $requiredColumns = ['title', 'image', 'release_at', 'summary'];
            $missingColumns = array_diff($requiredColumns, $header);

            if (!empty($missingColumns)) {
                throw new Exception("Missing required columns: " . implode(", ", $missingColumns));
            }

            // Begin transaction
            $conn->beginTransaction();

            $insertStmt = $conn->prepare("
                INSERT INTO members (title, image, release_at, summary) 
                VALUES (:title, :image, :release_at, :summary)
            ");

            $rowNumber = 1;
            while (($row = fgetcsv($handle, 1000, ";")) !== FALSE) {
                $rowNumber++;

                // Skip empty rows
                if (empty(array_filter($row))) {
                    continue;
                }

                // Debug row data
                $result['debug'][] = "Processing row $rowNumber: " . implode(", ", $row);

                // Create associative array from row data
                if (count($header) !== count($row)) {
                    $result['errors']++;
                    $result['messages'][] = "Error on row {$rowNumber}: Column count mismatch";
                    continue;
                }

                $data = array_combine($header, $row);

                // Trim all values
                $data = array_map('trim', $data);

                // Validate row data
                $errors = validateCsvRow($data);

                if (empty($errors)) {
                    // Convert date format
                    $releaseDate = parseDate($data['release_at']);

                    try {
                        $insertStmt->execute([
                            ':title' => $data['title'],
                            ':image' => $data['image'],
                            ':release_at' => $releaseDate,
                            ':summary' => $data['summary']
                        ]);
                        $result['success']++;
                        $result['debug'][] = "Successfully inserted row $rowNumber";
                    } catch (PDOException $e) {
                        $result['errors']++;
                        $result['messages'][] = "Database error on row {$rowNumber}: " . $e->getMessage();
                        $result['debug'][] = "SQL error: " . $e->getMessage();
                    }
                } else {
                    $result['errors']++;
                    $result['messages'][] = "Error on row {$rowNumber}: " . implode(", ", $errors);
                }
            }

            // If we have successful imports and no errors, commit
            if ($result['success'] > 0 && $result['errors'] === 0) {
                $conn->commit();
                $result['messages'][] = "Successfully imported {$result['success']} records.";
            } else {
                $conn->rollBack();
                if ($result['errors'] > 0) {
                    $result['messages'][] = "Import failed with {$result['errors']} errors. All changes were rolled back.";
                } else {
                    $result['messages'][] = "No valid records found to import.";
                }
                $result['success'] = 0;
            }

            fclose($handle);
        } else {
            throw new Exception("Could not open CSV file");
        }
    } catch (Exception $e) {
        $result['errors']++;
        $result['messages'][] = "Error: " . $e->getMessage();
        $result['debug'][] = "Exception: " . $e->getMessage();

        if (isset($conn) && $conn->inTransaction()) {
            $conn->rollBack();
        }
    }

    return $result;
}