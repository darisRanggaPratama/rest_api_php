<div class="sidebar">
    <div class="sidebar-header">
        <h3>Menu</h3>
    </div>
    <ul class="list-unstyled">
        <li>
            <a href="index.php" class="active">
                <i class="fas fa-home"></i> Home
            </a>
        </li>
        <li>
            <a href="#">
                <i class="fas fa-users"></i> Members
            </a>
        </li>
        <li>
            <a href="#">
                <i class="fas fa-cog"></i> Settings
            </a>
        </li>
    </ul>
</div>
