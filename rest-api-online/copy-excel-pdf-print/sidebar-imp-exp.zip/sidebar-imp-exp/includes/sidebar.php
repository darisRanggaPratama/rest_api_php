<div class="sidebar">
    <nav class="sidebar-nav">
        <a href="index.php" class="sidebar-link">
            <i class="fas fa-home me-2"></i> Dashboard
        </a>
        <a href="movies.php" class="sidebar-link">
            <i class="fas fa-film me-2"></i> Movies
        </a>
        <a href="characters.php" class="sidebar-link">
            <i class="fas fa-mask me-2"></i> Characters
        </a>
        <a href="actors.php" class="sidebar-link">
            <i class="fas fa-user me-2"></i> Actors
        </a>
        <a href="settings.php" class="sidebar-link">
            <i class="fas fa-cog me-2"></i> Settings
        </a>
    </nav>
</div>

<button class="toggle-btn">
    <i class="fas fa-bars fa-lg"></i>
</button>